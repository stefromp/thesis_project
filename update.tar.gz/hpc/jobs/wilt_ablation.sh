#!/bin/bash -l

#SBATCH --job-name=wilt_ablation
#SBATCH --output=/work/pr019/atvoulo/Rompos/jobs_out/wilt_ablation.out
#SBATCH --error=/work/pr019/atvoulo/Rompos/jobs_out/wilt_ablation.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=26
#SBATCH --time=24:00:00
#SBATCH --mem=120G
#SBATCH --partition=gpu

# ===========================================================================
# TODO(GPU) -- FILL THIS IN BEFORE SUBMITTING. This is the ONLY line to edit.
# "gpu:a100:1" is rejected on this cluster ("invalid GRES format or GPU type").
# Find the accepted string with:      sinfo -p gpu -o "%N %G"
# then uncomment the line below with that value, e.g. #SBATCH --gres=gpu:1
#
##SBATCH --gres=gpu:1
#
# Alternatively leave it commented and let hpc/submit_all.sh pass it on the
# sbatch command line (GRES=... ./hpc/submit_all.sh) -- a command-line --gres
# overrides this directive, so you only have to get it right in one place.
# ===========================================================================

# Enable if submission is rejected for a missing account association
# (association: account=pr019022_gpu, partitions gpu and mig).
##SBATCH --account=pr019022_gpu

# NOTE: the #SBATCH --output/--error paths above are literal on purpose.
# SLURM parses these directives before any shell expansion, so they cannot use
# $HPC_ROOT. If you move HPC_ROOT, update those two lines too -- they are the
# only place in this file where the root is spelled out twice.

# Verbatim from the cluster's job template -- kept byte-for-byte on purpose,
# so the x-prefix comparison and unquoted expansion are intentional here.
# shellcheck disable=SC2268,SC2086
if [ x$SLURM_CPUS_PER_TASK == x ]; then
  export OMP_NUM_THREADS=1
else
  export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
fi

module purge
module load hdf5
module load python/3.10
module load cuda/11.8
module load cmake

export TORCH_CUDA_ARCH_LIST="8.0"

# --- not -e: a failing combination must not kill the loop -------------------
set -uo pipefail

# ---------------------------------------------------------------------------
# Paths. Defined once, overridable from the environment.
# ---------------------------------------------------------------------------
HPC_ROOT="${HPC_ROOT:-/work/pr019/atvoulo/Rompos}"
REPO_ROOT="${REPO_ROOT:-${HPC_ROOT}/thesis_project}"
PYTHON_BIN="${PYTHON_BIN:-${HPC_ROOT}/venvs/tabddpm310/bin/python}"

# ---------------------------------------------------------------------------
# Warm-up: number of training steps that keep the fixed top-k path before
# adaptive_jenks takes over. 0 = adaptive from step 0. Change it HERE only.
# ---------------------------------------------------------------------------
TOPK_WARMUP_STEPS="${TOPK_WARMUP_STEPS:-0}"

K_MIN="${K_MIN:-1}"
TOPK_LOG_EVERY="${TOPK_LOG_EVERY:-100}"
DEVICE="${DEVICE:-cuda:0}"
SEED="${SEED:-0}"

DATASET="wilt"

export HPC_ROOT REPO_ROOT PYTHON_BIN DATASET TOPK_WARMUP_STEPS K_MIN \
       TOPK_LOG_EVERY DEVICE SEED

# shellcheck source-path=SCRIPTDIR
# shellcheck source=../common.sh
. "${REPO_ROOT}/hpc/common.sh"

run_dataset
